import React from 'react'
import './UserInfo.css'

export const UserInfo = () => {
  return (
    <div>
        This feature is currently under development.<br/>
        Updating and Deleting user account,<br/>
        Sending Push Notification.<br/>
    </div>
  )
}
