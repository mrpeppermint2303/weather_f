import React from 'react'
import './Navbar.css'
import { Link } from 'react-router-dom'

export const Navbar = () => {

  return (
    <div className='nav-bar'>
        <div className='nav-login-cart'>
            {localStorage.getItem('auth-token')
            ?<>
            <button onClick={()=>{window.location.replace('/winfo')}}>Dashboard</button>
            <button onClick={()=>{localStorage.removeItem('auth-token');window.location.replace('/Login')}}>Logout</button>
            <button onClick={()=>{window.location.replace('/Ginfo')}}>UserInfo</button></>
            :<Link style={{textDecoration:'none'}} to='/Login'><button>Weather App Login</button></Link>}
        </div>
    </div>
  )
}
