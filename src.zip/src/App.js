import './App.css';
import { BrowserRouter,Routes,Route} from 'react-router-dom';
import { LoginSignup } from './pages/LoginSignup/LoginSignup';
import { Navbar } from './pages/Navbar/Navbar';
import { WeatherInfo } from './pages/weather_info/WeatherInfo';
import { UserInfo } from './pages/UserInfo/UserInfo';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path='/Login' element={<LoginSignup />}/> 
        <Route path='/winfo' element={<WeatherInfo />}/>
        <Route path='/Ginfo' element={<UserInfo />}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
